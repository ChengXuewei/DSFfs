###train###
trainDSF=function(data,splitrule,ntree){
  ##1-1 基于指定分离规则的训练
  train=data
  obj=rfsrc(Surv(time, status) ~ ., data = train,
              splitrule=splitrule,importance = TRUE,
              ntree = ntree, block.size = 1,statistics=TRUE) 
  sp=obj$survival.oob[,median(1:length(obj$time.interest))] ##OOB survival function
  y=obj$predicted.oob;  ##OOB predicted value
  VIMP=obj$importance;  ##OOB predicted value
  cindex=concordancefit(Surv(train$time,train$status),sp)$concordance
  return (list(obj=obj,sp=sp,y=y,cindex=cindex,VIMP=VIMP))
}