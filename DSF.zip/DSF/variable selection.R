###variable selection##
VS=function(VI1,VI2,VI3,VI4){
  V=VI1+VI2+VI3+VI4
  order=order(V,decreasing=FALSE)[1:2]
  names=names(VI1[order])
  return (list(names=names,order=order+2))
}