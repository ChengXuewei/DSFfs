##判断是低维数据还是高维数据
##针对高维数据，增加特征筛选的过程
BSIS=function(data){
  if (nrow(data)<ncol(data)){
    x=data[,3:ncol(data)];
    y=Surv(data$time,data$status)
    model=bcorsis(x=x,y=y,method = "survival")
    index=model$ix;index
    time=data$time
    status=data$status
    x=as.matrix(x)
    data=cbind(x[,index],time,status)
    colnames(data)[ncol(data)-1]="time";
    colnames(data)[ncol(data)]="status";
    data=as.data.frame(data)
  }
  return(data)
}
