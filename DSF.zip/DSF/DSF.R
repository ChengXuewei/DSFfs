DSF44=function(data,folds){
  ##第0步：加载程序包和设置默认路径##
  library(survival)
  library(randomForest)
  library(randomForestSRC)
  library(ipred)
  library(survcomp)
  library(Ball)
  library(SIS)
  library(caret)
  data=na.omit(data)   ##传入数据
  ##将低维的文本类型转化为因子类型
  if (ncol(data)<20){
    for (i in 1:ncol(data)){
      if (class(data[,i])=="character"){
        data[,i]=as.factor(data[,i])
      }
    }
  }
  
  F=folds     ##几折交叉验证
  ##第1步：针对高维数据进行特征筛选
  source("I:/Rproject/confidence screening/code/base code3/BSIS.R")
  data=BSIS(data)
  ##输入数据列规整
  data=cbind(subset(data,select=c(time,status)),subset(data,select=c(-time,-status)))
  ##训练集与测试集划分
  folds <- createFolds(1:nrow(data),k=F)
  Cresult=Bresult=matrix(0,F,6)
  B2result=B3result=matrix(0,F,6)
  for (j in 1:F){  ##交叉验证
  train=rtrain=data[-folds[[j]],];   ##训练集
  test=rtest=data[folds[[j]],];  ##测试集
  
  ##第2步：开始深层训练
  source("I:/Rproject/confidence screening/code/base code3/trainDSF.R")
  ##2-1 第1层训练
  train11=trainDSF(train,"logrank",500);
  train12=trainDSF(train,"logrankscore",500);
  train13=trainDSF(train,"bs.gradient",500);
  train14=trainDSF(train,"random",500);
  source("I:/Rproject/confidence screening/code/base code2/variable selection.R")
  VIMP1=VS(train11[[5]],train12[[5]],train13[[5]],train14[[5]])
  train=train[,-VIMP1[[2]]]
  
  ##2-2 第2层训练
  ##Max-pooling
  out1=as.matrix(cbind(train11[[3]],train12[[3]],train13[[3]],train14[[3]]));
  Y11=apply(out1,1,max);
  ##error-screening
  C1=c(train11[[4]],train12[[4]],train13[[4]],train14[[4]])
  index1=which(C1==max(C1))
  Y12=out1[,index1]
  train=cbind(train,Y11,Y12);
  colnames(train)[ncol(train)-1]="Y1";
  colnames(train)[ncol(train)]="Y2";head(train)
  train21=trainDSF(train,"logrank",500);
  train22=trainDSF(train,"logrankscore",500);
  train23=trainDSF(train,"bs.gradient",500);
  train24=trainDSF(train,"random",500);
  VIMP2=VS(train21[[5]],train22[[5]],train23[[5]],train24[[5]])
  train=train[,-VIMP2[[2]]]
  
  ##2-3 第3层训练
  ##Max-pooling
  out2=as.matrix(cbind(train21[[3]],train22[[3]],train23[[3]],train24[[3]]));
  Y21=apply(out2,1,max);
  ##error-screening
  C2=c(train21[[4]],train22[[4]],train23[[4]],train24[[4]])
  index2=which(C2==max(C2))
  Y22=out2[,index2]
  train=cbind(train,Y21,Y22);
  colnames(train)[ncol(train)-1]="Y3";
  colnames(train)[ncol(train)]="Y4";head(train)
  train31=trainDSF(train,"logrank",500);
  train32=trainDSF(train,"logrankscore",500);
  train33=trainDSF(train,"bs.gradient",500);
  train34=trainDSF(train,"random",500);
  

  
  ##第3步：开始测试
  source("I:/Rproject/confidence screening/code/base code3/testDSF.R")
  ##3-1 第1层测试
  test11=testDSF(train11[[1]],test)
  test12=testDSF(train12[[1]],test)
  test13=testDSF(train13[[1]],test)
  test14=testDSF(train14[[1]],test)
  test=test[,-VIMP1[[2]]]
  
  ##3-2 第2层测试
  out4=as.matrix(cbind(test11[[1]],test12[[1]],test13[[1]],test14[[1]]));
  Y41=apply(out4,1,max);
  ##error-screening
  Y42=out4[,index1]
  test=cbind(test,Y41,Y42);
  colnames(test)[ncol(test)-1]="Y1";
  colnames(test)[ncol(test)]="Y2";head(test)
  test21=testDSF(train21[[1]],test)
  test22=testDSF(train22[[1]],test)
  test23=testDSF(train23[[1]],test)
  test24=testDSF(train24[[1]],test)
  test=test[,-VIMP2[[2]]]
  
  ##3-3 第3层测试
  out5=as.matrix(cbind(test21[[1]],test22[[1]],test23[[1]],test24[[1]]));
  Y51=apply(out5,1,max);
  ##error-screening
  Y52=out5[,index2]
  test=cbind(test,Y51,Y52);
  colnames(test)[ncol(test)-1]="Y3";
  colnames(test)[ncol(test)]="Y4";head(test)
  test31=testDSF(train31[[1]],test)
  test32=testDSF(train32[[1]],test)
  test33=testDSF(train33[[1]],test)
  test34=testDSF(train34[[1]],test)

  
  ##第4步：RSF ##
  OBJ=rfsrc(Surv(time, status) ~ ., data = rtrain,
            ntree =500, block.size = 1,statistics=TRUE);
  PRE=predict(OBJ,rtest);
  


  
  ##第5步：开始评价模型的好坏
  ##5-1 c-index
  sp=(test31[[1]]+test32[[1]]+test33[[1]]+test34[[1]])/4  ##单点sp
  sf=(test31[[3]]+test32[[3]]+test33[[3]]+test34[[3]])/4 ##Sp function
  TM=floor(median(1:length(OBJ$time.interest)))
  SP=PRE$survival[,TM];
  SF=PRE$survival;
  Y=Surv(rtest$time,rtest$status)
  Cindex1=concordancefit(Y,test31[[1]])$concordance;Cindex1
  Cindex2=concordancefit(Y,test32[[1]])$concordance;Cindex2
  Cindex3=concordancefit(Y,test33[[1]])$concordance;Cindex3
  Cindex4=concordancefit(Y,test34[[1]])$concordance;Cindex4
  Cindex5=concordancefit(Y,sp)$concordance;Cindex5
  Cindex6=concordancefit(Y,SP)$concordance;Cindex6
  Cindex=cbind(Cindex1,Cindex2,Cindex3,Cindex4,Cindex5,Cindex6)
  
  #5-2 计算BRIER-SCORE（单点）
  tindex=floor(median((1:length(OBJ$time.interest))))
  mtime=OBJ$time.interest[tindex]  ##单点时间
  brier21=sbrier(Y,as.vector(test31[[1]]),btime=mtime)[1]
  brier22=sbrier(Y,as.vector(test32[[1]]),btime=mtime)[1]
  brier23=sbrier(Y,as.vector(test33[[1]]),btime=mtime)[1]
  brier24=sbrier(Y,as.vector(test34[[1]]),btime=mtime)[1]
  brier25=sbrier(Y,as.vector(sp),btime=mtime)[1]
  brier26=sbrier(Y,as.vector(SP),btime=mtime)[1]
  brier2=cbind(brier21,brier22,brier23,brier24,brier25,brier26)
  
  #5-3 计算BRIER-SCORE（单点）-zhp
  library(final526)
  mtime=median(OBJ$time.interest)  ##单点时间
  brier31=mybrier(Y,as.vector(test31[[1]]),mtime)
  brier32=mybrier(Y,as.vector(test32[[1]]),mtime)
  brier33=mybrier(Y,as.vector(test33[[1]]),mtime)
  brier34=mybrier(Y,as.vector(test34[[1]]),mtime)
  brier35=mybrier(Y,as.vector(sp),mtime)
  brier36=mybrier(Y,as.vector(SP),mtime)
  brier3=cbind(brier31,brier32,brier33,brier34,brier35,brier36)
  
  #5-4 计算Integrated BRIER-SCORE（积分）-zhp
  Itime=c(0,max(rtest$time))  ##一段时间
  brier41=myIBS(Y,as.matrix(test31[[3]]),Itime)
  brier42=myIBS(Y,as.matrix(test32[[3]]),Itime)
  brier43=myIBS(Y,as.matrix(test33[[3]]),Itime)
  brier44=myIBS(Y,as.matrix(test34[[3]]),Itime)
  brier45=myIBS(Y,as.matrix(sf),Itime)
  brier46=myIBS(Y,as.matrix(SF),Itime)
  brier4=as.vector(cbind(brier41[[1]],brier42[[1]],brier43[[1]],brier44[[1]],brier45[[1]],brier46[[1]]))
  Cresult[j,]=round(Cindex,4)
  Bresult[j,]=round(brier2,4)
  B2result[j,]=round(brier3,4)
  B3result[j,]=round(brier4,4)
}
  return (list(Cresult=Cresult,Bresult=Bresult,B2result=B2result,B3result=B3result))
}
  
  
  
  