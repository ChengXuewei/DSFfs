#RIST Paper Scenario 1
library(MASS)

gendata1 <- function(n,p,rho)# n sample size; p dimension.
{
 # rho=0.9
  sig <- matrix(0,p, p);
  
  sig <- rho^abs(row(sig) - col(sig));
  diag(sig)<-rep(1,p);
  X <- mvrnorm(n,rep(0,p),sig);  
  mu=abs(0.1*(sum(X[,c(5:10)])))  
  
  T <- rexp(n,1/mu);
  #c controls the censoring rate 33% 默认2
  C <- rexp(n,1/(mu*1.5));
  status <- as.numeric(T<=C);
  time <- pmin(T,C);
  return(list(X=X,time=time,status=status));
}

#RIST Paper Scenario 2
gendata2 <- function(n,p,rho)# n sample size; p dimension.
{
  X = data.frame(replicate(p, runif(n)))
  mu=sin(X[,1]*pi)+2*abs(X[,2]-0.5)+X[,3]^3
 
  T <- rexp(n,1/mu);
  TAU=3;#TAU controls the censoring rate, TAU=6 produce approximately 22% censoring rate
  C=runif(n,0, TAU)
  status <- as.numeric(T<=C);
  time <- pmin(T,C);
  return(list(X=X,time=time,status=status));
}

#RIST Paper Scenario 3

gendata3 <- function(n,p,rho)# n sample size; p dimension.
{
  
  sig <- matrix(0,p, p);
  
  sig <- rho^abs(row(sig) - col(sig));
  diag(sig)<-rep(1,p);
  #sig <- matrix(0.35,p, p);
  #sig[1:5,1:5] <- 0.35;
  #diag(sig)<-rep(1,p);
  X <- mvrnorm(n,rep(0,p),sig);
  
  mu=0.5+abs(0.3*(sum(X[,c(5:10)])))
  sca=2
  
  T <- rgamma(n,mu/sca,scale=sca);
  TAU=200;#c0 controls the censoring rate, TAU=55 produce approximately 39% censoring rate
  C=runif(n,0,TAU)
  
  status <- as.numeric(T<=C);
  time <- pmin(T,C);
  return(list(X=X,time=time,status=status));
}

gendata4 <- function(n,p,rho)# n sample size; p dimension.
  {
  #rho=0.75 
  sig <- matrix(0,p, p)
  sig <- rho^abs(row(sig) - col(sig));
  diag(sig)<-rep(1,p);
  X <- mvrnorm(n,rep(0,p),sig);
  mu=abs(0.1*(sum(X[,c(1:5)])))+abs(0.1*(sum(X[,c(10:15)])))
  #Lognormal
  T <- rlnorm(n,mu)
  C= rlnorm(n,mu+0.3)  ##mu+0.5
  status <- as.numeric(T<=C)
  time <- pmin(T,C)
  return(list(X=X,time=time,status=status))
 }

# l1 splitting forest
#Ten iid uniform covariates on the interval (0,1) are available, X1,..., X10, but the response is only #related to X1. The censoring times are uniformly distributed on the interval (0,α). The

gendata5 <- function(n,p,rho)# n sample size; p dimension.
{
  # p iid uniform covariates on the interval (0,1)
  X = data.frame(replicate(p, runif(n)))
  temp=runif(n)
  T=replicate(n,0)
  for (i in 1:n){
    if (X[i,1]<=0.5){
      if (temp[i]<=(1-exp(-0.5*0.27*2*2))){
        f <- function(x,y)  (1-exp(-0.27*0.5*x*x)-y)	
        T[i]=uniroot(f, y=temp[i], lower=0.001, upper=100000000)$root	
      }else{
        f <- function(x,y)  (1-exp(-0.1*x*x-5*x+9.86)-y)	
        T[i]=uniroot(f, y=temp[i], lower=0.001, upper=100000000)$root	
      }   
    }else{
      if (temp[i]<=(1-exp(-0.05*6*6))){
        f <- function(x,y)  (1-exp(-0.05*x*x)-y)	
        T[i]=uniroot(f, y=temp[i], lower=0.001, upper=100000000)$root	
      }else{
        #f <- function(x,y)  (1-exp(-2.75*x*x+32.4*x-97.2)-y)	
        #T[i]=uniroot(f, y=temp[i], lower=0.001, upper=100000000)$root	
        T[i] <- (64.8/11)+((64.8/11)^2-(97.2*4/11)-(20/55)*log(1-temp[i]))^(1/2);		
      }   
    }
    
  }
  
  TAU=5;#TAU controls the censoring rate, TAU=10 produce approximately 18% censoring rate
  C=runif(n, 0, 5*TAU)
  status <- as.numeric(T<=C);
  time <- pmin(T,C);
  return(list(X=X,time=time,status=status));
}