###test###
testDSF=function(model,data){
  test=data
  ##1-1 基于指定模型的测试
  pre=predict(model,test);
  sp=pre$survival[,median(1:length(model$time.interest))];
  z=pre$predicted; 
  return (list(sp=sp,z=z))
}

